# VideoTools – Mac Edition

Benvenuto! Questo pacchetto contiene uno script per scaricare video da YouTube.

## ⚠️ Prerequisiti

Apri il terminale e installa i due strumenti necessari:

```
brew install yt-dlp ffmpeg
```

## ▶️ Come si usa?

1. Salva `scarica_video.sh` nella tua cartella `~/VideoTools`
2. Quando l'estensione ti propone il file `.sh`, apri il terminale e lancia:

```
bash scarica_video.sh "URL del video"
```

Il video verrà scaricato e unito in `video.mp4`.
