#!/bin/bash
cd ~/VideoTools
yt-dlp -f bestvideo+bestaudio "$1" -o "video.%(ext)s"
ffmpeg -i "video.fvideo.mp4" -i "video.faudio.webm" -c copy "video.mp4"
read -p "Premi invio per uscire..."
