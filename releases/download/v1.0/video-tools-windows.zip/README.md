# VideoTools – Windows Edition

Benvenuto! Questo pacchetto contiene tutto il necessario per scaricare video da YouTube in formato MP4.

## ▶️ Come si usa?

1. Estrai tutto in una cartella (es: Desktop)
2. Fai clic con il tasto destro su `SETUP.bat` > Esegui come amministratore
3. Dopo il setup, fai doppio clic su `scarica_video.bat` quando l'estensione te lo propone

Il video verrà scaricato e unito automaticamente in `video.mp4`!
